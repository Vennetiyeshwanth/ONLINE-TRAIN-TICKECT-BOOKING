package p1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JSpinner;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;

public class train3 {

	 JFrame frame;
	private JTextField name;
	private JTextField age;
	private JTextField total;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					flight3 window = new flight3(0);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * @wbp.parser.entryPoint
	 */
	public train3(int x) {
		initialize(x);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(int x) {
		frame = new JFrame();
		frame.setBounds(100, 100, 771, 646);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("NAME");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel.setBounds(22, 33, 164, 46);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblAge = new JLabel("AGE");
		lblAge.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblAge.setBounds(22, 119, 164, 46);
		frame.getContentPane().add(lblAge);
		
		JLabel lblGender = new JLabel("GENDER");
		lblGender.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblGender.setBounds(22, 204, 164, 46);
		frame.getContentPane().add(lblGender);
		
		name = new JTextField();
		name.setFont(new Font("Tahoma", Font.PLAIN, 20));
		name.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				if(!(e.getKeyChar()>='a' && e.getKeyChar()<='z') && !(e.getKeyChar()>='A' && e.getKeyChar()<='Z'))
					e.consume();
			}
		});
		name.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(name.getText().length()==0)
					name.requestFocus();
			}
		});
		name.setBounds(184, 33, 244, 46);
		frame.getContentPane().add(name);
		name.setColumns(10);
		
		age = new JTextField();
		age.setFont(new Font("Tahoma", Font.PLAIN, 20));
		age.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				if(!Character.isDigit(e.getKeyChar()))
					e.consume();
			}
		});
		age.setColumns(10);
		age.setBounds(184, 119, 82, 46);
		frame.getContentPane().add(age);
		
		JComboBox gender = new JComboBox();
		gender.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
			}
		});
		gender.setFont(new Font("Tahoma", Font.PLAIN, 15));
		gender.setModel(new DefaultComboBoxModel(new String[] {"<----Select Gender---->", "Male", "Female", "Other"}));
		gender.setBounds(184, 204, 143, 46);
		frame.getContentPane().add(gender);
		
		JLabel lblBogi = new JLabel("BOGI");
		lblBogi.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblBogi.setBounds(22, 300, 164, 46);
		frame.getContentPane().add(lblBogi);
		
		JComboBox bogi = new JComboBox();
		bogi.setFont(new Font("Tahoma", Font.PLAIN, 17));
		bogi.setModel(new DefaultComboBoxModel(new String[] {"Select Bogi", "S1", "S2", "S3", "S4", "S5", "S6", "S7"}));
		bogi.setBounds(184, 300, 143, 46);
		frame.getContentPane().add(bogi);
		
		JLabel lblSeat = new JLabel("Seat Number");
		lblSeat.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblSeat.setBounds(22, 393, 164, 46);
		frame.getContentPane().add(lblSeat);
		
		JComboBox seat = new JComboBox();
		seat.setModel(new DefaultComboBoxModel(new String[] {"Seat", "11", "22", "33", "44", "55", "66", "77", "88"}));
		seat.setFont(new Font("Tahoma", Font.PLAIN, 18));
		seat.setBounds(184, 393, 143, 46);
		frame.getContentPane().add(seat);
		
		JLabel lblTotal = new JLabel("TOTAL");
		lblTotal.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTotal.setBounds(430, 231, 82, 46);
		frame.getContentPane().add(lblTotal);
		
		total = new JTextField();
		total.setEditable(false);
		total.setFont(new Font("Tahoma", Font.PLAIN, 20));
		total.setColumns(10);
		total.setBounds(542, 232, 82, 46);
		frame.getContentPane().add(total);
		
		JButton Book = new JButton("BOOK");
		Book.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(name.getText().length()==0)
					JOptionPane.showMessageDialog(Book, "Please enter name");
				else if(age.getText().length()==0)
					JOptionPane.showMessageDialog(Book, "Please enter age");
				else if(gender.getSelectedIndex()<1)
					JOptionPane.showMessageDialog(Book, "Please slect gender");
				else if(bogi.getSelectedIndex()<1)
					JOptionPane.showMessageDialog(Book, "Please select bogi");
				else if(seat.getSelectedIndex()<1)
					JOptionPane.showMessageDialog(Book, "Please select seat number");	
				else
				{
					total.setText(Integer.toString(x));
					try 
					{
						FileWriter fw=new FileWriter("D:\\SEMESTER 2\\Files\\Ctod_Projects\\q2_railway.txt",true);
						fw.append("\nName = "+name.getText());
						fw.append("\nAge = "+age.getText());
						fw.append("\nGender = "+gender.getSelectedItem().toString());
						fw.append("\nBogi = "+bogi.getSelectedItem().toString());
						fw.append("\nSeat Number = "+seat.getSelectedItem().toString());
						fw.append("\nTotal = "+total.getText());
						fw.append("\n\n\n\n");
						fw.flush();
					} 
					catch (IOException e1) 
					{
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
		});
		Book.setFont(new Font("Tahoma", Font.PLAIN, 20));
		Book.setBounds(97, 505, 143, 46);
		frame.getContentPane().add(Book);
		

		JLabel heading = new JLabel("");
		heading.setBounds(0, -27, 775, 634);
		frame.getContentPane().add(heading);
		ImageIcon icon=new ImageIcon("C:\\Users\\sonun\\OneDrive\\Desktop\\train3.jfif");
		Image imgscale=icon.getImage().getScaledInstance(heading.getWidth(), heading.getHeight(), Image.SCALE_SMOOTH);
		ImageIcon scaledicon=new ImageIcon(imgscale);
		heading.setIcon(scaledicon);;
	}
}
