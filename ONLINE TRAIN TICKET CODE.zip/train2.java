package p1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;

import java.awt.event.ItemListener;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.event.ItemEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class train2 {

	JFrame frame;
	private int[] price=new int[] {450,432,567,876,214,976,356,765,456,743};
	train3 r3,r4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					flight2 window = new flight2();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * @wbp.parser.entryPoint
	 */
	public train2() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 550, 630);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(505, 354, 5, 22);
		frame.getContentPane().add(textArea);
		
		JLabel lblNewLabel = new JLabel("BOOK TICKETS");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 24));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(116, 11, 293, 50);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("SOURCE");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(24, 92, 176, 41);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("DESTINATION");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_1_1.setBounds(24, 167, 176, 41);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("TRAIN");
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_1_2.setBounds(24, 244, 176, 41);
		frame.getContentPane().add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("CATEGORY");
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_1_3.setBounds(24, 319, 176, 41);
		frame.getContentPane().add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_4 = new JLabel("COACHES");
		lblNewLabel_1_4.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_1_4.setBounds(24, 397, 176, 41);
		frame.getContentPane().add(lblNewLabel_1_4);
		
		JComboBox source = new JComboBox();
		source.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
			}
		});
		source.setModel(new DefaultComboBoxModel(new String[] {"<---------Starting Point---------->", "Chhatrapati Shivaji Terminus", "Ghum", "Dudhsagar", "Char Bagh", "Howrah Station", "New Delhi Railway Station", "Cuttack", "Vijayawada", "Trivandrum Centra", "Dwarka"}));
		source.setBounds(281, 96, 195, 41);
		frame.getContentPane().add(source);
		
		JComboBox destination = new JComboBox();
		destination.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(source.getSelectedIndex()==destination.getSelectedIndex())
					JOptionPane.showMessageDialog(destination, "Source and Destination cannot be same");
			}
			
		});
		destination.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				/*if(source.getSelectedIndex()==destination.getSelectedIndex())
					JOptionPane.showMessageDialog(destination, "Source and Destination cannot be same");*/
			}
		});
		destination.setModel(new DefaultComboBoxModel(new String[] {"<----------End Point----------->", "Chhatrapati Shivaji Terminus", "Ghum", "Dudhsagar", "Char Bagh", "Howrah Station", "New Delhi Railway Station", "Cuttack", "Vijayawada", "Trivandrum Centra", "Dwarka"}));
		destination.setBounds(281, 167, 195, 41);
		frame.getContentPane().add(destination);
		
		JComboBox train = new JComboBox();
		train.setModel(new DefaultComboBoxModel(new String[] {"<---------Select Train--------->", "Rajdhani Express", "Duronto Express", "Shatabdi Express", "Sampark Kranti Express", "Garib Rath Express", "Vande Bharat Express", "Maharaja Express ", "Humsafar Express", "Samjhauta Express", "Chamundi Express"}));
		train.setBounds(281, 244, 195, 41);
		frame.getContentPane().add(train);
		
		JComboBox category = new JComboBox();
		category.setModel(new DefaultComboBoxModel(new String[] {"<-------Select Category------->", "Express", "Superfast "}));
		category.setBounds(281, 319, 195, 41);
		frame.getContentPane().add(category);
		
		JComboBox coaches = new JComboBox();
		coaches.setModel(new DefaultComboBoxModel(new String[] {"<--------Select Coach--------->", "AC", "NON-AC"}));
		coaches.setBounds(281, 397, 195, 41);
		frame.getContentPane().add(coaches);
		
		JButton submit = new JButton("Submit");
		submit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				if(source.getSelectedIndex()<1)
					JOptionPane.showMessageDialog(submit, "Please select Source");
				else if(destination.getSelectedIndex()<1)
					JOptionPane.showMessageDialog(submit, "Please select Destination");
				else if(train.getSelectedIndex()<1)
					JOptionPane.showMessageDialog(submit, "Please select Train");
				else if(category.getSelectedIndex()<1)
					JOptionPane.showMessageDialog(submit, "Please select Category");
				else if(coaches.getSelectedIndex()<1)
					JOptionPane.showMessageDialog(submit, "Please select Coach");
				else if(source.getSelectedIndex()==destination.getSelectedIndex())
					JOptionPane.showMessageDialog(destination, "Source and Destination cannot be same");
				else
				{
					try 
					{
						FileWriter fw=new FileWriter("D:\\SEMESTER 2\\Files\\Ctod_Projects\\q2_railway.txt",true);
						fw.append("\nSource = "+source.getSelectedItem().toString());
						fw.append("\nDestination = "+destination.getSelectedItem().toString());
						fw.append("\nTrain = "+train.getSelectedItem().toString());
						fw.append("\nCategory = "+category.getSelectedItem().toString());
						fw.append("\nCoaches = "+coaches.getSelectedItem().toString());
						fw.flush();
					} 
					catch (IOException e1) 
					{
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					int x=destination.getSelectedIndex();
					r3=new train3(price[x]);
					r3.frame.setVisible(true);
					frame.dispose();
				}
			}
		});
		submit.setFont(new Font("Tahoma", Font.PLAIN, 21));
		submit.setBounds(202, 499, 121, 50);
		frame.getContentPane().add(submit);
		
		JLabel heading = new JLabel("");
		heading.setBounds(0, -27, 536, 634);
		frame.getContentPane().add(heading);
		ImageIcon icon=new ImageIcon("C:\\Users\\sonun\\OneDrive\\Desktop\\train2.jpg");
		Image imgscale=icon.getImage().getScaledInstance(heading.getWidth(), heading.getHeight(), Image.SCALE_SMOOTH);
		ImageIcon scaledicon=new ImageIcon(imgscale);
		heading.setIcon(scaledicon);;

	}
}
