package p1;

import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class train1 {

	private JFrame frame;
	train2 r2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					train1 window = new train1();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public train1() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 505, 533);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel heading = new JLabel("");
		heading.setBounds(10, 11, 471, 363);
		frame.getContentPane().add(heading);
		ImageIcon icon=new ImageIcon("C:\\Users\\sonun\\OneDrive\\Desktop\\train1.jfif");
		Image imgscale=icon.getImage().getScaledInstance(heading.getWidth(), heading.getHeight(), Image.SCALE_SMOOTH);
		ImageIcon scaledicon=new ImageIcon(imgscale);
		heading.setIcon(scaledicon);
		
		JButton bookhead = new JButton("Book Tickets");
		bookhead.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				r2=new train2();
				r2.frame.setVisible(true);
				frame.dispose();
			}
		});
		bookhead.setFont(new Font("Tahoma", Font.PLAIN, 20));
		bookhead.setBounds(174, 414, 150, 52);
		frame.getContentPane().add(bookhead);
	}
}
